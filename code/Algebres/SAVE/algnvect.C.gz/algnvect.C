// Algebre en dimension n
// Partie I : scalaires, angles et vecteurs
//
// EB Mai 93
// EB Nov 93 : revision
// LD Nov 93 : add convolution, min, max
// (c) Copyright TIMC 1993

#include <algebre.h>
#include <math.h>
#include <stdio.h>

//
// Constructeurs et destructeurs
// =============================
//

void Vecteur::Alloue()
// Alloue n Scalaires dans x (privee)
	{
	x=new Scalaire [n];
	}

Vecteur::Vecteur(int d)
// Alloue un vecteur non initialise de dimension d
	{
	n=d;
	Alloue();
	}

Vecteur::Vecteur(Scalaire x1,Scalaire x2)
// Alloue et initialise le vecteur (x1,x2)
	{
	n=2;
	Alloue();
	x[0]=x1;
	x[1]=x2;
	}

Vecteur::Vecteur(Scalaire x1,Scalaire x2,Scalaire x3)
// Alloue et initialise le vecteur (x1,x2,x3)
	{
	n=3;
	Alloue();
	x[0]=x1;
	x[1]=x2;
	x[2]=x3;
	}

Vecteur::Vecteur(Scalaire x1,Scalaire x2,Scalaire x3,Scalaire x4)
// Alloue le vecteur (x1,x2,x3,x4)
	{
	n=4;
	Alloue();
	x[0]=x1;
	x[1]=x2;
	x[2]=x3;
	x[3]=x4;
	}

Vecteur::~Vecteur()
// Libere le vecteur
	{
	delete [] x;
	}

//
// Initialisations
// ===============
//

void Vecteur::Nul()
// Recoit (0,0,...,0)
	{
	int i;
	for (i=0;i<n;i++)
		x[i]=0.0;
	}

void Vecteur::Canonique(int i)
// Recoit (0,0,...,0,1,0,...,0) avec le 1 en ieme coordonnee
	{
	Nul();
	x[i-1]=1.0;
	}

// Set fixe les 2,3 ou 4 premieres coordonnees

void Vecteur::Set(Scalaire x,Scalaire y)
	{
	(*this)(1)=x;
	(*this)(2)=y;
	}

void Vecteur::Set(Scalaire x,Scalaire y,Scalaire z)
	{
	(*this)(1)=x;
	(*this)(2)=y;
	(*this)(3)=z;
	}

void Vecteur::Set(Scalaire x,Scalaire y,Scalaire z,Scalaire t)
	{
	(*this)(1)=x;
	(*this)(2)=y;
	(*this)(3)=z;
	(*this)(4)=t;
	}

//
// Acces structure
// ===============
//

Scalaire & Vecteur::operator () (int i)
// Acces a la ieme composante
	{
#if CHECK
	if (i<1 || i>n)
		fputs("Erreur : Adressage vecteur hors limites\n",stderr);
#endif
	return *(x + (i-1));
	}

int Vecteur::N()
// Taille
	{
	return n;
	}

//
// Operateurs
// ==========
//

void Copy(Vecteur *a,Vecteur *b)
// b <- a
	{
	int i;
	for (i=1;i<=a->N();i++)
		(*b)(i)=(*a)(i);
	}

void Mul(Scalaire k,Vecteur *u,Vecteur *v)
// v <- k.u
	{
	int i;
	for (i=1;i<=u->N();i++)
		(*v)(i)=k*(*u)(i);
	}

void Add(Vecteur *u,Vecteur *v,Vecteur *w)
// w <- u+v
	{
	int i;
	for (i=1;i<=u->N();i++)
		(*w)(i)=(*u)(i)+(*v)(i);
	}

void KAdd(Vecteur *u,Scalaire k,Vecteur *v,Vecteur *w)
// w <- u+k.v
	{
	int i;
	for (i=1;i<=u->N();i++)
		(*w)(i)=(*u)(i)+k*(*v)(i);
	}

Scalaire Scal(Vecteur *u,Vecteur *v)
// <- <u,v>
	{
	Scalaire s;
	int i;
	for (i=1,s=0.0;i<=u->N();i++)
		s+=(*u)(i)*(*v)(i);
	return s;
	}

void Normalise(Vecteur *u,Vecteur *v)
// v <- u/Norme(u)
	{
	Scalaire s;
	s=1.0/Norme(u);
	Mul(s,u,v);
	}

void Decompose(Vecteur *u,Vecteur *n,Vecteur *v)
// v <- u-(<u,n>/<n,n>).n (u prive de sa composante // a n)
	{
	Scalaire s;
	s= -Scal(u,n)/Scal(n,n);
	KAdd(u,s,n,v);
	}

Scalaire Norme2(Vecteur *u)
// <- <u,u>
	{
	return Scal(u,u);
	}

Scalaire Norme(Vecteur *u)
// <- Norme(u)
	{
	Scalaire s;
	s=Norme2(u);
	if (s<1.0e-6) return s*1.0e3;
	else return sqrt(s);
	}

Scalaire Det(Vecteur *u,Vecteur *v)
// <- Det(u,v) de dimension 2
	{
	return (*u)(1)*(*v)(2)-(*u)(2)*(*v)(1);
	}

Scalaire Det(Vecteur *u,Vecteur *v,Vecteur *w)
// <- Det(u,v,w) de dimension 3
	{
	return	 (*u)(1)*(*v)(2)*(*w)(3)
			+(*u)(2)*(*v)(3)*(*w)(1)
			+(*u)(3)*(*v)(1)*(*w)(2)
			-(*u)(1)*(*v)(3)*(*w)(2)
			-(*u)(2)*(*v)(1)*(*w)(3)
			-(*u)(3)*(*v)(2)*(*w)(1);
	}

void PVect(Vecteur *u,Vecteur *v,Vecteur *w)
// w <- u ^ v tous de dimension 3
	{
	Vecteur h(3);
	h(1)=(*u)(2)*(*v)(3)-(*u)(3)*(*v)(2);
	h(2)=(*u)(3)*(*v)(1)-(*u)(1)*(*v)(3);
	h(3)=(*u)(1)*(*v)(2)-(*u)(2)*(*v)(1);
	Copy(&h,w);
	}

// LD begin

void Convol(Vecteur *u,Vecteur *v,Vecteur *w)
// w <- u+v
	{
	int i,j,k;
	for (i=1;i<=u->N();i++)
	for (j=1;j<=u->N();j++)
		k=(i-j);
		if(k<=0)k=k+(u->N());
		(*w)(i)=(*u)(j)*(*v)(k);
	}

