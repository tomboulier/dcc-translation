// Algebre en dimension n
// Partie I : scalaires, angles et vecteurs
//
// EB Mai 93
// EB Nov 93 : revision
// LD Nov 93 : modification

// (c) Copyright TIMC 1993

#ifndef __ALGNVECT_H
#define __ALGNVECT_H

#include <math.h>
#include <typescalaire.h>
//
// ========
// Vecteurs
// ========
//

class Vecteur
	{
	private:
		int n;			// Dimension
		Scalaire *x;	// Coordonnees
		void Alloue();	// Alloue x de dimension n
	public:
		//
		// Constructeurs et destructeurs
		// =============================
		//
		Vecteur(int n=3);
			// Alloue un vecteur non initialise de dimension n
		Vecteur(Scalaire x,Scalaire y);
			// Alloue et initialise le vecteur (x,y)
		Vecteur(Scalaire x,Scalaire y,Scalaire z);
			// Alloue et initialise le vecteur (x,y,z)
		Vecteur(Scalaire x,Scalaire y,Scalaire z,Scalaire t);
			// Alloue et initialise le vecteur (x,y,z,t)
		~Vecteur();
			// Libere le vecteur
		//
		// Initialisations
		// ===============
		//
		void Nul();
			// Recoit (0,0,...,0)
		void Canonique(int i);
			// Recoit (0,0,...,0,1,0,...,0) avec le 1 en ieme coordonnee
		// Set fixe les 2,3 ou 4 premieres coordonnees
		void Set(Scalaire x,Scalaire y);
		void Set(Scalaire x,Scalaire y,Scalaire z);
		void Set(Scalaire x,Scalaire y,Scalaire z,Scalaire t);
		//
		// Acces structure
		// ===============
		//
		Scalaire & operator () (int i);
			// Acces a la ieme composante
		int N();
			// Taille
	};

//
// Operateurs
// ==========
//

void Copy(Vecteur *a,Vecteur *b);
// b <- a
void Mul(Scalaire k,Vecteur *u,Vecteur *v);
// v <- k.u
void Add(Vecteur *u,Vecteur *v,Vecteur *w);
// w <- u+v
void KAdd(Vecteur *u,Scalaire k,Vecteur *v,Vecteur *w);
// w <- u+k.v
Scalaire Scal(Vecteur *u,Vecteur *v);
// <- <u,v>
void Normalise(Vecteur *u,Vecteur *v);
// v <- u/Norme(u)
void Decompose(Vecteur *u,Vecteur *n,Vecteur *v);
// v <- u-(<u,n>/<n,n>).n (u prive de sa composante // a n)
Scalaire Norme2(Vecteur *u);
// <- <u,u>
Scalaire Norme(Vecteur *u);
// <- Norme(u)
Scalaire Det(Vecteur *u,Vecteur *v);
// <- Det(u,v) de dimension 2
Scalaire Det(Vecteur *u,Vecteur *v,Vecteur *w);
// <- Det(u,v,w) de dimension 3
void PVect(Vecteur *u,Vecteur *v,Vecteur *w);
// w <- u ^ v tous de dimension 3

//LD
void Convol(Vecteur *u,Vecteur *v,Vecteur *w);
// w <- u*v


#endif

