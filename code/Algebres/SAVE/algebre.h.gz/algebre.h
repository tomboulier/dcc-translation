// Librairie d'algebre en dimension finie quelconque
//
// EB Mai 93

// (c) Copyright TIMC 1993
// adapted Laurent Desbat. 1993
#ifndef __ALGEBRE_H
#define __ALGEBRE_H

#define CHECK 1		// Test des adressages en dehors des objets

#include <algnvect.h>
/* 
#include <algnmat.h>
#include <algnmat2.h>
#include <algnpt.h>
#include <algnaff.h>
#include <algntpes.h>
#include <solide.h>
*/

#endif
